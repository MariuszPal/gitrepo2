/*
 * szkielet.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
	cout  << "Witaj w CPP";
	return 0;
}

